import Link from "next/link";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-orvex-fog/60 bg-orvex-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link href="/" className="flex items-center gap-2">
          <svg width="26" height="26" viewBox="0 0 64 64" aria-hidden>
            <rect width="64" height="64" rx="14" fill="#0A0A0B" />
            <path
              d="M18 44 L32 18 L46 44 M23 44 L32 27 L41 44"
              stroke="#C9A24B"
              strokeWidth="2.5"
              fill="none"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          </svg>
          <span className="text-lg font-semibold tracking-tight text-orvex-black">ORVEX</span>
        </Link>

        <nav className="hidden items-center gap-8 text-sm font-medium text-orvex-slate md:flex">
          <Link href="/send-money/chile-to-venezuela" className="hover:text-orvex-black">
            Enviar dinero
          </Link>
          <Link href="/login" className="hover:text-orvex-black">
            Iniciar sesión
          </Link>
        </nav>

        <Link
          href="/signup"
          className="rounded-full bg-orvex-black px-5 py-2.5 text-sm font-medium text-orvex-white transition hover:bg-orvex-graphite"
        >
          Crear cuenta gratis
        </Link>
      </div>
    </header>
  );
}
