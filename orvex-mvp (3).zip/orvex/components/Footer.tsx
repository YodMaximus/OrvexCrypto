import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-orvex-fog bg-orvex-white">
      <div className="mx-auto max-w-6xl px-5 py-12 text-sm text-orvex-mist">
        <div className="mb-8 flex items-center gap-2">
          <span className="text-base font-semibold tracking-tight text-orvex-black">ORVEX</span>
        </div>

        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div>
            <p className="mb-3 font-medium text-orvex-black">Producto</p>
            <ul className="space-y-2">
              <li><Link href="/send-money/chile-to-venezuela" className="hover:text-orvex-black">Chile → Venezuela</Link></li>
              <li><Link href="/signup" className="hover:text-orvex-black">Crear cuenta</Link></li>
            </ul>
          </div>
          <div>
            <p className="mb-3 font-medium text-orvex-black">Legal</p>
            <ul className="space-y-2">
              <li><Link href="/legal/terms" className="hover:text-orvex-black">Términos y Condiciones</Link></li>
              <li><Link href="/legal/privacy" className="hover:text-orvex-black">Política de Privacidad</Link></li>
              <li><Link href="/legal/risk" className="hover:text-orvex-black">Divulgación de Riesgo</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-orvex-fog pt-6 text-xs leading-relaxed text-orvex-mist">
          ORVEX es una plataforma tecnológica. ORVEX no es un banco, no custodia fondos de clientes
          y no garantiza transferencias. Las operaciones financieras dependerán de proveedores de
          servicios financieros autorizados y disponibles en cada jurisdicción. Todas las cotizaciones
          mostradas en este MVP son demostrativas ("Demo quote") y no representan tipos de cambio reales.
          <div className="mt-3">© {new Date().getFullYear()} ORVEX. Todos los derechos reservados.</div>
        </div>
      </div>
    </footer>
  );
}
