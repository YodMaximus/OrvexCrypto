"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface QuoteResult {
  sendAmount: number;
  receiveAmount: number;
  exchangeRate: number;
  orvexFee: number;
  providerFee: number;
  estimatedMinutes: number;
}

export default function Calculator() {
  const [sendAmount, setSendAmount] = useState(300000);
  const [quote, setQuote] = useState<QuoteResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    const timeout = setTimeout(async () => {
      if (!sendAmount || sendAmount <= 0) return;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch("/api/quotes", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            originCountry: "CL",
            destinationCountry: "VE",
            sendCurrency: "CLP",
            receiveCurrency: "USD",
            sendAmount,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "No se pudo cotizar.");
        setQuote(data.quote);
      } catch (e) {
        if ((e as Error).name !== "AbortError") setError("No se pudo generar la cotización.");
      } finally {
        setLoading(false);
      }
    }, 400);
    return () => {
      clearTimeout(timeout);
      controller.abort();
    };
  }, [sendAmount]);

  return (
    <div className="w-full max-w-md rounded-xl2 border border-orvex-fog bg-white p-6 shadow-card">
      <div className="mb-5 flex items-center justify-between text-xs font-medium uppercase tracking-wide text-orvex-mist">
        <span>Desde</span>
        <span>Hacia</span>
      </div>
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2 text-lg font-semibold text-orvex-black">
          <span>🇨🇱</span> Chile
        </div>
        <div className="h-px flex-1 mx-4 bg-orvex-fog" />
        <div className="flex items-center gap-2 text-lg font-semibold text-orvex-black">
          <span>🇻🇪</span> Venezuela
        </div>
      </div>

      <label className="mb-1 block text-xs font-medium text-orvex-mist">Tú envías</label>
      <div className="mb-5 flex items-center rounded-lg border border-orvex-fog px-4 py-3 focus-within:border-orvex-black">
        <input
          type="number"
          min={1000}
          value={sendAmount}
          onChange={(e) => setSendAmount(Number(e.target.value))}
          className="w-full bg-transparent text-2xl font-semibold text-orvex-black outline-none"
        />
        <span className="text-sm font-medium text-orvex-mist">CLP</span>
      </div>

      <label className="mb-1 block text-xs font-medium text-orvex-mist">El destinatario recibe</label>
      <div className="mb-5 rounded-lg bg-orvex-charcoal px-4 py-3 text-2xl font-semibold text-orvex-white">
        {loading ? (
          <span className="text-orvex-mist text-lg">Calculando…</span>
        ) : quote ? (
          `$${quote.receiveAmount.toLocaleString("es-CL", { minimumFractionDigits: 2 })} USD`
        ) : (
          "—"
        )}
      </div>

      {error && <p className="mb-4 text-sm text-red-600">{error}</p>}

      {quote && !error && (
        <div className="mb-5 space-y-2 text-sm text-orvex-slate">
          <div className="flex justify-between"><span>Comisión</span><span>${(quote.orvexFee + quote.providerFee).toLocaleString("es-CL")} CLP</span></div>
          <div className="flex justify-between"><span>Tipo de cambio</span><span>1 CLP = {quote.exchangeRate} USD</span></div>
          <div className="flex justify-between"><span>Tiempo estimado</span><span>{quote.estimatedMinutes} min</span></div>
        </div>
      )}

      <p className="mb-4 text-[11px] leading-relaxed text-orvex-mist">
        Cotización de demostración — no representa una transferencia real ni un tipo de cambio vigente.
      </p>

      <Link
        href="/signup"
        className="block w-full rounded-full bg-orvex-black py-3.5 text-center text-sm font-semibold text-orvex-white transition hover:bg-orvex-graphite"
      >
        Continuar
      </Link>
    </div>
  );
}
