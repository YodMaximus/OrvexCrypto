/**
 * Control de acceso al panel admin.
 * MVP: allowlist por email vía variable de entorno ORVEX_ADMIN_EMAILS
 * (separados por coma). En producción, reemplazar por roles reales
 * en la tabla users/profiles.
 */
export function isAdminEmail(email: string) {
  const list = (process.env.ORVEX_ADMIN_EMAILS ?? "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
  // Si no se configuró ninguna allowlist, en modo demo se permite
  // el acceso a cualquier usuario autenticado para poder ver el panel.
  if (list.length === 0) return true;
  return list.includes(email.toLowerCase());
}
