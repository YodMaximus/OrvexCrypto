/**
 * ORVEX — Data layer
 * ------------------------------------------------------------------
 * MVP: store en memoria (se reinicia con el servidor).
 * Esquema diseñado 1:1 para migrar a Postgres/Supabase sin
 * rediseñar el modelo de datos: solo hay que reemplazar las
 * funciones de este archivo por queries reales (ver comentarios
 * "MIGRATE TO SUPABASE" en cada función).
 *
 * Tablas representadas: users, profiles, recipients, transactions,
 * transaction_events, quotes, providers, provider_routes,
 * kyc_profiles, audit_logs, notifications, referrals, campaigns.
 * ------------------------------------------------------------------
 */

import { randomUUID } from "crypto";

export type KycStatus =
  | "NOT_STARTED"
  | "PENDING"
  | "VERIFIED"
  | "REJECTED"
  | "REVIEW_REQUIRED";

export type TransferStatus =
  | "PENDING"
  | "PROCESSING"
  | "COMPLETED"
  | "FAILED"
  | "CANCELLED";

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  passwordHash: string;
  passwordSalt: string;
  country: string;
  phone: string;
  referralCode: string;
  referredBy?: string | null;
  createdAt: string;
}

export interface KycProfile {
  userId: string;
  status: KycStatus;
  riskLevel: "LOW" | "MEDIUM" | "HIGH" | "UNKNOWN";
  countryRisk: "LOW" | "MEDIUM" | "HIGH" | "UNKNOWN";
  sanctionsScreeningStatus: "NOT_RUN" | "CLEAR" | "FLAGGED";
  kycProviderStatus: "MOCK_NOT_CONFIGURED";
  updatedAt: string;
}

export interface Recipient {
  id: string;
  userId: string;
  name: string;
  country: string;
  payoutMethod: string;
  payoutDetails: Record<string, string>;
  createdAt: string;
}

export interface Quote {
  id: string;
  userId: string;
  originCountry: string;
  destinationCountry: string;
  sendCurrency: string;
  receiveCurrency: string;
  sendAmount: number;
  receiveAmount: number;
  exchangeRate: number;
  orvexFee: number;
  providerFee: number;
  providerId: string;
  estimatedMinutes: number;
  createdAt: string;
  expiresAt: string;
  isDemo: true;
}

export interface TransactionEvent {
  id: string;
  transactionId: string;
  status: TransferStatus;
  note: string;
  createdAt: string;
}

export interface Transaction {
  id: string; // ORVEX Transaction ID
  userId: string;
  recipientId: string;
  originCountry: string;
  destinationCountry: string;
  sendAmount: number;
  sendCurrency: string;
  receiveAmount: number;
  receiveCurrency: string;
  orvexFee: number;
  providerFee: number;
  providerId: string;
  status: TransferStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ReferralHit {
  id: string;
  referralCode: string;
  source?: string;
  campaign?: string;
  medium?: string;
  timestamp: string;
}

export interface AuditLog {
  id: string;
  actorId: string | null;
  action: string;
  meta: Record<string, unknown>;
  createdAt: string;
}

export interface NotificationRecord {
  id: string;
  userId: string;
  channel: "EMAIL" | "SMS" | "PUSH";
  event: string;
  isMock: true;
  createdAt: string;
}

// ------------------------------------------------------------------
// In-memory tables
// ------------------------------------------------------------------
const users = new Map<string, User>();
const usersByEmail = new Map<string, string>(); // email -> id
const kycProfiles = new Map<string, KycProfile>();
const recipients = new Map<string, Recipient>();
const quotes = new Map<string, Quote>();
const transactions = new Map<string, Transaction>();
const transactionEvents = new Map<string, TransactionEvent[]>();
const referralHits: ReferralHit[] = [];
const auditLogs: AuditLog[] = [];
const notifications: NotificationRecord[] = [];
const sessions = new Map<string, { userId: string; expiresAt: number }>();

export const db = {
  // --- users --------------------------------------------------
  // MIGRATE TO SUPABASE: INSERT INTO users ... / SELECT ... WHERE email = $1
  createUser(input: Omit<User, "id" | "createdAt" | "referralCode">) {
    const id = randomUUID();
    const referralCode = `ORVEX-${(input.firstName || "USER")
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "")
      .slice(0, 10)}${Math.floor(Math.random() * 900 + 100)}`;
    const user: User = {
      ...input,
      id,
      referralCode,
      createdAt: new Date().toISOString(),
    };
    users.set(id, user);
    usersByEmail.set(input.email.toLowerCase(), id);
    kycProfiles.set(id, {
      userId: id,
      status: "NOT_STARTED",
      riskLevel: "UNKNOWN",
      countryRisk: "UNKNOWN",
      sanctionsScreeningStatus: "NOT_RUN",
      kycProviderStatus: "MOCK_NOT_CONFIGURED",
      updatedAt: new Date().toISOString(),
    });
    return user;
  },
  getUserByEmail(email: string) {
    const id = usersByEmail.get(email.toLowerCase());
    return id ? users.get(id) ?? null : null;
  },
  getUserById(id: string) {
    return users.get(id) ?? null;
  },
  listUsers() {
    return Array.from(users.values());
  },

  // --- kyc ------------------------------------------------------
  getKyc(userId: string) {
    return kycProfiles.get(userId) ?? null;
  },

  // --- sessions ---------------------------------------------------
  // MIGRATE TO SUPABASE: usar Supabase Auth en vez de sesiones propias.
  createSession(userId: string) {
    const token = randomUUID();
    sessions.set(token, { userId, expiresAt: Date.now() + 1000 * 60 * 60 * 24 * 7 });
    return token;
  },
  getSession(token: string) {
    const s = sessions.get(token);
    if (!s) return null;
    if (s.expiresAt < Date.now()) {
      sessions.delete(token);
      return null;
    }
    return s;
  },
  destroySession(token: string) {
    sessions.delete(token);
  },

  // --- recipients -------------------------------------------------
  createRecipient(input: Omit<Recipient, "id" | "createdAt">) {
    const r: Recipient = { ...input, id: randomUUID(), createdAt: new Date().toISOString() };
    recipients.set(r.id, r);
    return r;
  },
  listRecipients(userId: string) {
    return Array.from(recipients.values()).filter((r) => r.userId === userId);
  },
  getRecipient(id: string) {
    return recipients.get(id) ?? null;
  },

  // --- quotes -------------------------------------------------------
  saveQuote(q: Quote) {
    quotes.set(q.id, q);
    return q;
  },
  getQuote(id: string) {
    return quotes.get(id) ?? null;
  },

  // --- transactions ---------------------------------------------------
  createTransaction(input: Omit<Transaction, "id" | "createdAt" | "updatedAt">) {
    const now = new Date().toISOString();
    const t: Transaction = { ...input, id: randomUUID(), createdAt: now, updatedAt: now };
    transactions.set(t.id, t);
    transactionEvents.set(t.id, [
      { id: randomUUID(), transactionId: t.id, status: t.status, note: "Transfer created (DEMO)", createdAt: now },
    ]);
    return t;
  },
  updateTransactionStatus(id: string, status: TransferStatus, note: string) {
    const t = transactions.get(id);
    if (!t) return null;
    t.status = status;
    t.updatedAt = new Date().toISOString();
    transactions.set(id, t);
    const events = transactionEvents.get(id) ?? [];
    events.push({ id: randomUUID(), transactionId: id, status, note, createdAt: t.updatedAt });
    transactionEvents.set(id, events);
    return t;
  },
  getTransaction(id: string) {
    return transactions.get(id) ?? null;
  },
  listTransactionsByUser(userId: string) {
    return Array.from(transactions.values())
      .filter((t) => t.userId === userId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  },
  listAllTransactions() {
    return Array.from(transactions.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  },
  getTransactionEvents(id: string) {
    return transactionEvents.get(id) ?? [];
  },

  // --- referrals -------------------------------------------------
  recordReferralHit(hit: Omit<ReferralHit, "id" | "timestamp">) {
    const h: ReferralHit = { ...hit, id: randomUUID(), timestamp: new Date().toISOString() };
    referralHits.push(h);
    return h;
  },
  listReferralHits() {
    return referralHits;
  },

  // --- audit / notifications (mock) -------------------------------
  audit(actorId: string | null, action: string, meta: Record<string, unknown> = {}) {
    auditLogs.push({ id: randomUUID(), actorId, action, meta, createdAt: new Date().toISOString() });
  },
  listAuditLogs() {
    return auditLogs;
  },
  notifyMock(userId: string, channel: NotificationRecord["channel"], event: string) {
    const n: NotificationRecord = {
      id: randomUUID(),
      userId,
      channel,
      event,
      isMock: true,
      createdAt: new Date().toISOString(),
    };
    notifications.push(n);
    // eslint-disable-next-line no-console
    console.log(`[MOCK NOTIFICATION][${channel}] user=${userId} event=${event}`);
    return n;
  },
  listNotifications(userId: string) {
    return notifications.filter((n) => n.userId === userId);
  },

  // --- admin stats -------------------------------------------------
  stats() {
    const allTx = Array.from(transactions.values());
    return {
      totalUsers: users.size,
      totalTransfers: allTx.length,
      completedTransfers: allTx.filter((t) => t.status === "COMPLETED").length,
      failedTransfers: allTx.filter((t) => t.status === "FAILED").length,
      pendingTransfers: allTx.filter((t) => t.status === "PENDING" || t.status === "PROCESSING").length,
      totalVolumeCLP: allTx
        .filter((t) => t.sendCurrency === "CLP")
        .reduce((sum, t) => sum + t.sendAmount, 0),
      referralHits: referralHits.length,
    };
  },
};
