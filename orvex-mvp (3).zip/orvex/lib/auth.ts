/**
 * ORVEX — Auth helpers
 * ------------------------------------------------------------------
 * MVP: hashing con scrypt (nativo de Node, sin dependencias externas
 * para no depender de instalar paquetes con acceso a red).
 * Sesión: cookie httpOnly con token opaco validado contra el store
 * en memoria (lib/db.ts). En producción real, reemplazar por
 * Supabase Auth o un JWT firmado con ORVEX_SESSION_SECRET.
 * ------------------------------------------------------------------
 */
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { db } from "./db";

const SESSION_COOKIE = "orvex_session";

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string) {
  const candidate = scryptSync(password, salt, 64);
  const stored = Buffer.from(hash, "hex");
  if (candidate.length !== stored.length) return false;
  return timingSafeEqual(candidate, stored);
}

export async function createSessionCookie(userId: string) {
  const token = db.createSession(userId);
  const c = await cookies();
  c.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
  return token;
}

export async function getCurrentUser() {
  const c = await cookies();
  const token = c.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const session = db.getSession(token);
  if (!session) return null;
  return db.getUserById(session.userId);
}

export async function destroySessionCookie() {
  const c = await cookies();
  const token = c.get(SESSION_COOKIE)?.value;
  if (token) db.destroySession(token);
  c.delete(SESSION_COOKIE);
}

export const SESSION_COOKIE_NAME = SESSION_COOKIE;
