import es from "./es.json";
import en from "./en.json";

export type Locale = "es" | "en";
export const DEFAULT_LOCALE: Locale = "es";

const dictionaries: Record<Locale, Record<string, string>> = { es, en };

export function t(key: string, locale: Locale = DEFAULT_LOCALE): string {
  return dictionaries[locale][key] ?? dictionaries[DEFAULT_LOCALE][key] ?? key;
}
