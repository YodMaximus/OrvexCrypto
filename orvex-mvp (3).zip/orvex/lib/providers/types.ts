/**
 * ORVEX — Payment Provider Architecture
 * ------------------------------------------------------------------
 * Esta es la interfaz que CUALQUIER proveedor financiero real
 * (remesadora, banco, rail de stablecoins, etc.) debe implementar
 * para conectarse a ORVEX. Hoy solo existen implementaciones MOCK
 * (ver mockProviders.ts). Ninguna de ellas mueve dinero real.
 *
 * Para conectar un proveedor real:
 *   1. Crear una clase que implemente PaymentProviderAdapter.
 *   2. Usar credenciales desde variables de entorno (nunca hardcode).
 *   3. Registrarla en `lib/providers/registry.ts`.
 *   4. Marcar `isLive: true` únicamente cuando exista contrato,
 *      licencia/autorización aplicable y credenciales reales.
 * ------------------------------------------------------------------
 */

export interface ProviderQuoteRequest {
  originCountry: string;
  destinationCountry: string;
  sendCurrency: string;
  receiveCurrency: string;
  sendAmount: number;
}

export interface ProviderQuoteResult {
  providerId: string;
  providerName: string;
  exchangeRate: number;
  receiveAmount: number;
  providerFee: number;
  estimatedMinutes: number;
}

export interface ProviderTransferRequest {
  quoteId: string;
  senderUserId: string;
  recipientId: string;
  sendAmount: number;
}

export interface ProviderTransferResult {
  providerTransferId: string;
  status: "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED";
}

export interface PaymentProviderAdapter {
  id: string;
  name: string;
  /** true solo si está conectado a infraestructura financiera real y autorizada */
  isLive: boolean;

  getSupportedCountries(): string[];
  getSupportedCurrencies(): string[];
  createQuote(req: ProviderQuoteRequest): Promise<ProviderQuoteResult>;
  createTransfer(req: ProviderTransferRequest): Promise<ProviderTransferResult>;
  getTransferStatus(providerTransferId: string): Promise<ProviderTransferResult["status"]>;
  cancelTransfer(providerTransferId: string): Promise<boolean>;
}
