import { PaymentProviderAdapter, ProviderQuoteRequest, ProviderQuoteResult, ProviderTransferRequest, ProviderTransferResult } from "./types";

/**
 * DEMO PROVIDERS — NO conectados a infraestructura financiera real.
 * Los tipos de cambio y tiempos son simulados para efectos de UI/UX.
 * Cuando se conecte un proveedor real, isLive debe pasar a true y
 * los números deben venir de la API del proveedor, nunca de aquí.
 */

// Tasa base ilustrativa CLP -> USD (DEMO). NO usar como referencia real.
const BASE_RATE_CLP_USD = 0.00105;

function makeMockProvider(
  id: string,
  name: string,
  feePct: number,
  rateSpreadPct: number,
  minutes: number
): PaymentProviderAdapter {
  return {
    id,
    name,
    isLive: false,
    getSupportedCountries() {
      return ["CL", "VE"];
    },
    getSupportedCurrencies() {
      return ["CLP", "USD", "VES"];
    },
    async createQuote(req: ProviderQuoteRequest): Promise<ProviderQuoteResult> {
      const rate = BASE_RATE_CLP_USD * (1 - rateSpreadPct);
      const gross = req.sendAmount * rate;
      const providerFee = Math.round(req.sendAmount * feePct) / 1000;
      const receiveAmount = Math.max(0, Math.round((gross - gross * feePct) * 100) / 100);
      return {
        providerId: id,
        providerName: name,
        exchangeRate: Number(rate.toFixed(6)),
        receiveAmount,
        providerFee: Number((req.sendAmount * feePct).toFixed(2)),
        estimatedMinutes: minutes,
      };
    },
    async createTransfer(_req: ProviderTransferRequest): Promise<ProviderTransferResult> {
      return {
        providerTransferId: `${id}-${Date.now()}`,
        status: "PROCESSING",
      };
    },
    async getTransferStatus(_providerTransferId: string): Promise<ProviderTransferResult["status"]> {
      return "PROCESSING";
    },
    async cancelTransfer(_providerTransferId: string): Promise<boolean> {
      return true;
    },
  };
}

export const providerA = makeMockProvider("provider-a", "Provider A (Demo)", 0.025, 0.004, 30);
export const providerB = makeMockProvider("provider-b", "Provider B (Demo)", 0.018, 0.009, 240);
export const providerC = makeMockProvider("provider-c", "Provider C (Demo)", 0.021, 0.006, 15);

export const allProviders: PaymentProviderAdapter[] = [providerA, providerB, providerC];
