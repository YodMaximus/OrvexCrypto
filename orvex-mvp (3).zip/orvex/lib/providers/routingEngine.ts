import { allProviders } from "./mockProviders";
import { ProviderQuoteRequest, ProviderQuoteResult } from "./types";

export interface RoutingOption extends ProviderQuoteResult {
  score: number;
}

/**
 * ORVEX Routing Engine
 * ------------------------------------------------------------------
 * Compara todos los providers disponibles para una ruta y devuelve
 * el recomendado según reglas configurables (hoy: prioriza mayor
 * monto recibido, con penalización leve por tiempo de entrega).
 * En producción, esto se puede extender con reglas por país,
 * disponibilidad en tiempo real, éxito histórico del provider, etc.
 * ------------------------------------------------------------------
 */
export async function routeQuote(req: ProviderQuoteRequest): Promise<{
  recommended: RoutingOption;
  options: RoutingOption[];
}> {
  const quotes = await Promise.all(allProviders.map((p) => p.createQuote(req)));

  const options: RoutingOption[] = quotes.map((q) => {
    // Score simple: prioriza monto recibido, penaliza minutos de espera.
    const score = q.receiveAmount - q.estimatedMinutes * 0.01;
    return { ...q, score };
  });

  options.sort((a, b) => b.score - a.score);

  return { recommended: options[0], options };
}
