/**
 * ORVEX — Analytics (mock)
 * ------------------------------------------------------------------
 * Eventos de producto centralizados. Hoy solo hacen console.log en
 * servidor. Para producción, conectar aquí PostHog/GA4/Mixpanel sin
 * tocar el resto del código (todos los eventos ya pasan por track()).
 * ------------------------------------------------------------------
 */
export type OrvexEvent =
  | "landing_view"
  | "signup_started"
  | "signup_completed"
  | "quote_created"
  | "recipient_added"
  | "transfer_started"
  | "transfer_confirmed"
  | "transfer_completed"
  | "referral_click";

export function track(event: OrvexEvent, meta: Record<string, unknown> = {}) {
  // eslint-disable-next-line no-console
  console.log(`[ORVEX ANALYTICS] ${event}`, meta);
}
