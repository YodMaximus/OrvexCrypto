# ORVEX — Send Money. Directly.

MVP funcional de plataforma de remesas P2P (corredor inicial: Chile → Venezuela).
Next.js 14 (App Router) + TypeScript + Tailwind. Sin dependencias de infraestructura
financiera real: todo lo relacionado a proveedores de pago está detrás de una
interfaz `PaymentProviderAdapter` con implementaciones **MOCK** claramente marcadas.

## A. Arquitectura

```
Usuario A → ORVEX (interfaz + routing engine) → Proveedor financiero autorizado → Usuario B
```

Capas separadas como pediste:
1. **Interfaz y software de ORVEX** — `app/`, `components/`
2. **Usuarios** — `lib/db.ts` (users, profiles, sessions)
3. **Motor de transferencias** — `app/api/transfers`, `app/api/quotes`
4. **Proveedores financieros (mock)** — `lib/providers/`
5. **Verificación/KYC** — `lib/db.ts` (kycProfiles) + `lib/admin.ts` — estructura lista, sin proveedor real conectado
6. **Liquidación/payout** — abstraído en `PaymentProviderAdapter.createTransfer()`

## B. Tecnologías

- Next.js 14 (App Router, Server Actions/Route Handlers)
- TypeScript
- Tailwind CSS
- Sin base de datos externa en el MVP (store en memoria, ver sección E)
- Sin dependencias de pago reales

## C. Estructura de carpetas

```
orvex/
  app/
    page.tsx                       → Landing + calculadora
    signup/, login/                → Auth
    dashboard/                     → Home, transfer wizard, recipients, tracking
    admin/                         → Panel admin (stats, usuarios, transferencias)
    send-money/chile-to-venezuela/ → Página SEO del corredor
    r/[code]/                      → Redirección de referidos
    legal/                         → Términos, privacidad, riesgo (placeholders)
    api/                           → Todos los endpoints backend
  lib/
    db.ts                          → "Base de datos" en memoria (esquema completo)
    auth.ts                        → Hashing + sesiones
    admin.ts                       → Allowlist de acceso a /admin
    analytics.ts                   → Eventos de producto (mock)
    providers/                     → PaymentProviderAdapter + routing engine + mocks
    i18n/                          → es.json / en.json
  components/                      → Navbar, Footer, Calculator
  middleware.ts                    → Protege /dashboard y /admin
```

## D. Base de datos (esquema)

Implementado como store en memoria en `lib/db.ts`, con el esquema completo pedido:
`users, profiles, recipients, transactions, transaction_events, quotes, providers,
kyc_profiles, audit_logs, notifications, referrals`.

**Importante:** al reiniciar el servidor, los datos se pierden (es memoria, no disco).
Para persistencia real, ver la sección "Cómo migrar a producción" abajo — el
esquema ya está diseñado para mapear 1:1 a tablas de Postgres/Supabase.

## E. Variables de entorno

Copia `.env.example` a `.env.local` y ajusta:

```
ORVEX_SESSION_SECRET=       # openssl rand -base64 32
NEXT_PUBLIC_APP_URL=        # http://localhost:3000 en local
ORVEX_ADMIN_EMAILS=         # opcional: tu@email.com,otro@email.com — si se deja vacío, cualquier usuario logueado puede ver /admin (solo para demo)
```

El resto de las variables (`SUPABASE_*`, `KYC_PROVIDER_API_KEY`, `EMAIL_PROVIDER_API_KEY`,
`PAYMENT_PROVIDER_*_API_KEY`) son para cuando conectes proveedores reales — no son
necesarias para correr el MVP.

## F. Cómo ejecutar localmente

Requisitos: Node.js 18.18+ (probado con Node 22).

```bash
cd orvex
npm install
cp .env.example .env.local
npm run dev
```

Abre `http://localhost:3000`.

## G. Cómo desplegar gratis (Vercel — recomendado)

1. Sube la carpeta `orvex/` a un repositorio de GitHub.
2. Entra a https://vercel.com → **Add New → Project** → importa el repo.
3. Vercel detecta Next.js automáticamente. En **Environment Variables** agrega:
   - `ORVEX_SESSION_SECRET` (genera uno con `openssl rand -base64 32`)
   - `NEXT_PUBLIC_APP_URL` = `https://<tu-proyecto>.vercel.app` (lo sabrás tras el primer deploy; redepliega una vez para que quede correcto)
   - `ORVEX_ADMIN_EMAILS` = tu email
4. Click **Deploy**.
5. Obtendrás una URL pública tipo `https://orvex-tuusuario.vercel.app`.

**Nota sobre persistencia en Vercel:** el store en memoria de este MVP vive dentro
de cada función serverless y **no persiste entre invocaciones ni se comparte entre
regiones**. Para una demo con tráfico de redes sociales verás inconsistencias
(ej. un usuario creado en una función no aparece en otra). Para ese caso, conecta
Supabase (gratis) — ver siguiente sección. Para una prueba local o un demo controlado,
el store en memoria funciona bien tal cual.

### Alternativa con persistencia real gratis: Supabase

1. Crea un proyecto gratis en https://supabase.com.
2. Ejecuta el SQL para crear las tablas listadas en la sección D (mismos nombres/campos que `lib/db.ts`).
3. Agrega `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` en Vercel.
4. Reemplaza las funciones de `lib/db.ts` por queries a Supabase (cada función tiene
   un comentario `MIGRATE TO SUPABASE` indicando qué query va ahí).

## H. URL pública

Este entorno de trabajo no tiene acceso a red saliente, así que no pude ejecutar
`npm install` ni desplegar por ti. Sigue la sección G — el proceso toma
~5 minutos y termina en una URL pública real.

## I. Qué partes son MOCK (no reales)

- **Proveedores de pago** (`lib/providers/mockProviders.ts`): tipos de cambio y
  tiempos simulados, marcados con `isLive: false`. No mueven dinero real.
- **KYC**: solo existe el modelo de datos y los estados (`NOT_STARTED`, `PENDING`,
  `VERIFIED`, etc.). No hay proveedor de verificación de identidad conectado.
- **Notificaciones** (email/SMS/push): se registran en logs del servidor como
  `[MOCK NOTIFICATION]`, no se envían realmente.
- **Persistencia**: store en memoria, no una base de datos real (a menos que
  conectes Supabase como se indica arriba).
- **Sanctions screening**: campo de estado presente, sin proveedor conectado.

Todo lo anterior está detrás de interfaces (`PaymentProviderAdapter`, `db.ts`)
para poder reemplazarse sin rediseñar el producto.

## J. Qué necesitas contratar/configurar para producción financiera real

1. **Licencia o alianza regulatoria** para operar como remesadora en Chile y
   Venezuela (o alianza con un proveedor ya licenciado — money transmitter license
   o equivalente).
2. **Proveedor de pagos/remesas real** (o varios) que implemente `PaymentProviderAdapter`.
3. **Proveedor KYC/AML** (ej. verificación de identidad + screening de sanciones).
4. **Cuenta bancaria/custodia** operada por el proveedor autorizado (ORVEX no debe custodiar fondos).
5. **Asesoría legal** para redactar Términos, Privacidad y Divulgación de Riesgo reales (hoy son placeholders).
6. **Proveedor de email/SMS transaccional** (ej. Resend, Twilio) para notificaciones reales.
7. **Base de datos persistente real** (Supabase/Postgres) en vez del store en memoria.
8. **Dominio propio** (orvex.com o el que definas) conectado en Vercel.
9. **Auditoría de seguridad** antes de manejar dinero de terceros.
10. **Monitoreo/observabilidad** (logs, alertas de fraude, límites de transacción).

## K. Próximos 10 pasos sugeridos

1. Desplegar en Vercel y validar el flujo completo en la URL pública.
2. Conectar Supabase para persistencia real de usuarios/transferencias.
3. Comprar/conectar el dominio `orvex.com` (o el que definas) en Vercel.
4. Redactar con un abogado los documentos legales reales (Términos, Privacidad, Riesgo).
5. Definir con qué proveedor de remesas real conversar primero para el corredor Chile→Venezuela.
6. Conectar un proveedor de email transaccional (ej. Resend) para reemplazar las notificaciones mock.
7. Agregar analytics real (PostHog o GA4) usando los eventos ya definidos en `lib/analytics.ts`.
8. Preparar los assets de marca (logo en alta resolución, favicon PNG, imagen OG) para redes sociales.
9. Lanzar el link de referidos (`/r/TUCODIGO`) en tus redes y monitorear `/admin` para ver conversión.
10. Iterar el flujo de KYC real una vez tengas proveedor y licencia definidos.

---

## Guía rápida de promoción (referral system ya integrado)

- Cada usuario registrado tiene un `referralCode` único (ej. `ORVEX-RAGNAR123`),
  visible en su dashboard con un botón de copiar.
- El link de referido es `https://tu-dominio.vercel.app/r/ORVEX-RAGNAR123`.
- Puedes añadir parámetros de campaña al link para saber de qué red viene cada clic:
  `/r/ORVEX-RAGNAR123?source=tiktok&campaign=lanzamiento&medium=video`
- Cada clic se registra en `referrals` y es visible en `/admin` (conteo total y,
  a nivel de datos, por código/fuente).
- Eventos de producto ya instrumentados para medir conversión de tu tráfico social:
  `landing_view → signup_completed → quote_created → transfer_confirmed → transfer_completed`.

**Sugerencia de copy para redes** (ejemplo, ajústalo a tu marca y evita afirmar que
ORVEX ya está licenciado o mueve dinero real hasta que sea cierto):

> ORVEX — Send Money. Directly. 🇨🇱→🇻🇪
> Cotiza tu envío en segundos, sin letra chica.
> Crea tu cuenta gratis: [tu link de referido]
