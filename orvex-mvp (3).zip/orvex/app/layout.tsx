import type { Metadata } from "next";
import "./globals.css";

const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(appUrl),
  title: "ORVEX — Send Money. Directly.",
  description: "Simple, transparent cross-border money transfer technology.",
  icons: { icon: "/favicon.svg" },
  openGraph: {
    title: "ORVEX — Send Money. Directly.",
    description: "Simple, transparent cross-border money transfer technology.",
    url: appUrl,
    siteName: "ORVEX",
    locale: "es_CL",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ORVEX — Send Money. Directly.",
    description: "Simple, transparent cross-border money transfer technology.",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
