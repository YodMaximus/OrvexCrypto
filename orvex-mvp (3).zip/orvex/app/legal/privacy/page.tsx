import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function PrivacyPage() {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-2xl px-5 py-16 text-sm leading-relaxed text-orvex-slate">
        <h1 className="mb-6 text-2xl font-semibold text-orvex-black">Política de Privacidad</h1>
        <p className="mb-4">
          [PLACEHOLDER — este documento debe ser redactado por un asesor legal, incluyendo el
          tratamiento de datos personales conforme a la normativa aplicable en cada país (por
          ejemplo, Ley 19.628 en Chile u otras normativas locales relevantes).]
        </p>
        <p className="mb-4">
          ORVEX recopila información mínima necesaria para operar la plataforma (cuenta,
          destinatarios, historial de transferencias). No se almacenan documentos de identidad
          sensibles más allá de lo estrictamente necesario, y la verificación de identidad (KYC)
          se realizará, cuando corresponda, a través de un proveedor externo especializado.
        </p>
        <p>Última actualización: [fecha pendiente de definición].</p>
      </main>
      <Footer />
    </>
  );
}
