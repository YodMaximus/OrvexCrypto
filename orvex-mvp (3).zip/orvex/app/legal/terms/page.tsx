import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function TermsPage() {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-2xl px-5 py-16 text-sm leading-relaxed text-orvex-slate">
        <h1 className="mb-6 text-2xl font-semibold text-orvex-black">Términos y Condiciones</h1>
        <p className="mb-4">
          [PLACEHOLDER — este documento debe ser redactado y revisado por un asesor legal antes
          del lanzamiento a producción.]
        </p>
        <p className="mb-4">
          ORVEX es una plataforma tecnológica. ORVEX no es una entidad bancaria, no está
          actualmente licenciada como remesadora en ninguna jurisdicción, y no custodia fondos de
          sus usuarios. El uso de la plataforma para transferencias reales dependerá de la
          integración con proveedores de servicios financieros debidamente autorizados en cada
          jurisdicción aplicable.
        </p>
        <p>Última actualización: [fecha pendiente de definición].</p>
      </main>
      <Footer />
    </>
  );
}
