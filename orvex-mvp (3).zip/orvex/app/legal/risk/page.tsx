import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function RiskPage() {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-2xl px-5 py-16 text-sm leading-relaxed text-orvex-slate">
        <h1 className="mb-6 text-2xl font-semibold text-orvex-black">Divulgación de Riesgo</h1>
        <p className="mb-4">
          [PLACEHOLDER — debe ser redactado por un asesor legal/regulatorio.]
        </p>
        <p className="mb-4">
          ORVEX es, en su etapa actual, un producto tecnológico en desarrollo (MVP). No garantiza
          la ejecución, el tiempo de entrega ni el tipo de cambio de ninguna transferencia. Las
          cotizaciones mostradas en el producto son demostrativas y no reflejan tipos de cambio ni
          tarifas reales hasta que se integren proveedores financieros autorizados.
        </p>
        <p>Última actualización: [fecha pendiente de definición].</p>
      </main>
      <Footer />
    </>
  );
}
