"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "No se pudo iniciar sesión.");
      router.push(params.get("next") ?? "/dashboard");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-md px-5 py-16">
        <h1 className="mb-8 text-2xl font-semibold text-orvex-black">Iniciar sesión</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input required type="email" placeholder="Email" value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg border border-orvex-fog px-4 py-3 text-sm outline-none focus:border-orvex-black" />
          <input required type="password" placeholder="Contraseña" value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-lg border border-orvex-fog px-4 py-3 text-sm outline-none focus:border-orvex-black" />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button disabled={loading} type="submit"
            className="w-full rounded-full bg-orvex-black py-3.5 text-sm font-semibold text-orvex-white transition hover:bg-orvex-graphite disabled:opacity-50">
            {loading ? "Ingresando…" : "Iniciar sesión"}
          </button>
        </form>
        <p className="mt-6 text-center text-sm text-orvex-mist">
          ¿No tienes cuenta? <Link href="/signup" className="font-medium text-orvex-black underline">Crear cuenta gratis</Link>
        </p>
      </main>
      <Footer />
    </>
  );
}
