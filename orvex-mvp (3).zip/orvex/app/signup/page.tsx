"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function SignupPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    country: "Chile",
    phone: "",
    password: "",
    acceptedTerms: false,
    acceptedPrivacy: false,
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, referralCode: params.get("ref") }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "No se pudo crear la cuenta.");
      router.push("/dashboard");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-md px-5 py-16">
        <h1 className="mb-2 text-2xl font-semibold text-orvex-black">Crear cuenta gratis</h1>
        <p className="mb-8 text-sm text-orvex-mist">Sin costo. Solo toma un minuto.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <input required placeholder="Nombre" className="input" value={form.firstName}
              onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
            <input required placeholder="Apellido" className="input" value={form.lastName}
              onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
          </div>
          <input required type="email" placeholder="Email" className="input" value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <input required placeholder="País" className="input" value={form.country}
            onChange={(e) => setForm({ ...form, country: e.target.value })} />
          <input required placeholder="Teléfono" className="input" value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <input required type="password" minLength={8} placeholder="Contraseña (mín. 8 caracteres)" className="input" value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })} />

          <label className="flex items-start gap-2 text-xs text-orvex-slate">
            <input type="checkbox" required checked={form.acceptedTerms}
              onChange={(e) => setForm({ ...form, acceptedTerms: e.target.checked })} className="mt-0.5" />
            Acepto los <Link href="/legal/terms" className="underline">Términos y Condiciones</Link>
          </label>
          <label className="flex items-start gap-2 text-xs text-orvex-slate">
            <input type="checkbox" required checked={form.acceptedPrivacy}
              onChange={(e) => setForm({ ...form, acceptedPrivacy: e.target.checked })} className="mt-0.5" />
            Acepto la <Link href="/legal/privacy" className="underline">Política de Privacidad</Link>
          </label>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button disabled={loading} type="submit"
            className="w-full rounded-full bg-orvex-black py-3.5 text-sm font-semibold text-orvex-white transition hover:bg-orvex-graphite disabled:opacity-50">
            {loading ? "Creando cuenta…" : "Crear cuenta gratis"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-orvex-mist">
          ¿Ya tienes cuenta? <Link href="/login" className="font-medium text-orvex-black underline">Iniciar sesión</Link>
        </p>
      </main>
      <Footer />

      <style>{`.input { width: 100%; border: 1px solid #E5E5E8; border-radius: 0.5rem; padding: 0.75rem 1rem; font-size: 0.9rem; outline: none; } .input:focus { border-color: #0A0A0B; }`}</style>
    </>
  );
}
