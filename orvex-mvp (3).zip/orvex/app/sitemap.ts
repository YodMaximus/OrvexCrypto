import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  return [
    { url: `${base}/`, priority: 1 },
    { url: `${base}/send-money/chile-to-venezuela`, priority: 0.9 },
    { url: `${base}/signup`, priority: 0.8 },
    { url: `${base}/login`, priority: 0.5 },
    { url: `${base}/legal/terms`, priority: 0.2 },
    { url: `${base}/legal/privacy`, priority: 0.2 },
    { url: `${base}/legal/risk`, priority: 0.2 },
  ];
}
