"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";

interface Stats {
  totalUsers: number;
  totalTransfers: number;
  completedTransfers: number;
  failedTransfers: number;
  pendingTransfers: number;
  totalVolumeCLP: number;
  referralHits: number;
}
interface UserRow { id: string; name: string; email: string; country: string; createdAt: string; referralCode: string }
interface TransferRow { id: string; userId: string; destinationCountry: string; sendAmount: number; sendCurrency: string; status: string; providerId: string; createdAt: string }

export default function AdminPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [transfers, setTransfers] = useState<TransferRow[]>([]);
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/admin/stats").then(async (r) => {
      const data = await r.json();
      if (!r.ok) { setError(data.error); return; }
      setStats(data.stats);
      setUsers(data.users);
      setTransfers(data.transfers);
    });
  }, []);

  if (error) {
    return (
      <>
        <Navbar />
        <main className="mx-auto max-w-2xl px-5 py-12 text-sm text-red-600">{error}</main>
      </>
    );
  }

  const filteredTransfers = statusFilter === "ALL" ? transfers : transfers.filter((t) => t.status === statusFilter);

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-6xl px-5 py-12">
        <h1 className="mb-8 text-2xl font-semibold text-orvex-black">Admin Dashboard</h1>

        {stats && (
          <div className="mb-10 grid grid-cols-2 gap-4 md:grid-cols-4">
            <Stat label="Usuarios" value={stats.totalUsers} />
            <Stat label="Transferencias" value={stats.totalTransfers} />
            <Stat label="Completadas" value={stats.completedTransfers} />
            <Stat label="Fallidas" value={stats.failedTransfers} />
            <Stat label="Pendientes" value={stats.pendingTransfers} />
            <Stat label="Volumen CLP (demo)" value={`$${stats.totalVolumeCLP.toLocaleString("es-CL")}`} />
            <Stat label="Clics de referidos" value={stats.referralHits} />
          </div>
        )}

        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-orvex-black">Transferencias</h2>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-lg border border-orvex-fog px-3 py-2 text-sm">
            <option value="ALL">Todos los estados</option>
            <option value="PENDING">Pendiente</option>
            <option value="PROCESSING">Procesando</option>
            <option value="COMPLETED">Completada</option>
            <option value="FAILED">Fallida</option>
          </select>
        </div>
        <div className="mb-12 overflow-x-auto rounded-xl2 border border-orvex-fog">
          <table className="w-full text-left text-sm">
            <thead className="bg-orvex-fog/40 text-xs uppercase text-orvex-mist">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Destino</th>
                <th className="px-4 py-3">Monto</th>
                <th className="px-4 py-3">Proveedor</th>
                <th className="px-4 py-3">Estado</th>
                <th className="px-4 py-3">Fecha</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransfers.map((t) => (
                <tr key={t.id} className="border-t border-orvex-fog">
                  <td className="px-4 py-3 font-mono text-xs">{t.id.slice(0, 8)}…</td>
                  <td className="px-4 py-3">{t.destinationCountry}</td>
                  <td className="px-4 py-3">${t.sendAmount.toLocaleString("es-CL")} {t.sendCurrency}</td>
                  <td className="px-4 py-3">{t.providerId}</td>
                  <td className="px-4 py-3">{t.status}</td>
                  <td className="px-4 py-3 text-orvex-mist">{new Date(t.createdAt).toLocaleDateString("es-CL")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <h2 className="mb-4 text-lg font-semibold text-orvex-black">Usuarios</h2>
        <div className="overflow-x-auto rounded-xl2 border border-orvex-fog">
          <table className="w-full text-left text-sm">
            <thead className="bg-orvex-fog/40 text-xs uppercase text-orvex-mist">
              <tr>
                <th className="px-4 py-3">Nombre</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">País</th>
                <th className="px-4 py-3">Código referido</th>
                <th className="px-4 py-3">Registrado</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-t border-orvex-fog">
                  <td className="px-4 py-3">{u.name}</td>
                  <td className="px-4 py-3">{u.email}</td>
                  <td className="px-4 py-3">{u.country}</td>
                  <td className="px-4 py-3 font-mono text-xs">{u.referralCode}</td>
                  <td className="px-4 py-3 text-orvex-mist">{new Date(u.createdAt).toLocaleDateString("es-CL")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl2 border border-orvex-fog p-4">
      <p className="text-xs text-orvex-mist">{label}</p>
      <p className="mt-1 text-xl font-semibold text-orvex-black">{value}</p>
    </div>
  );
}
