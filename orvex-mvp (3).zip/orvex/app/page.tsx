import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Calculator from "@/components/Calculator";
import Link from "next/link";

export default function Home() {
  return (
    <>
      <Navbar />

      <main className="bg-orvex-white">
        {/* HERO */}
        <section className="mx-auto max-w-6xl px-5 pb-16 pt-14 md:pb-24 md:pt-20">
          <div className="grid gap-12 md:grid-cols-2 md:items-center md:gap-8">
            <div>
              <h1 className="text-4xl font-semibold leading-[1.05] tracking-tight text-orvex-black md:text-6xl">
                Send Money.
                <br />
                <span className="text-orvex-gold">Directly.</span>
              </h1>
              <p className="mt-6 max-w-md text-lg leading-relaxed text-orvex-slate">
                Mueve dinero entre personas y países a través de una experiencia digital simple y transparente.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link
                  href="/signup"
                  className="rounded-full bg-orvex-black px-7 py-3.5 text-center text-sm font-semibold text-orvex-white transition hover:bg-orvex-graphite"
                >
                  Enviar dinero
                </Link>
                <Link
                  href="/signup"
                  className="rounded-full border border-orvex-fog px-7 py-3.5 text-center text-sm font-semibold text-orvex-black transition hover:border-orvex-black"
                >
                  Crear cuenta gratis
                </Link>
              </div>

              <div className="mt-12 grid grid-cols-4 gap-4 text-center">
                {["Rápido", "Transparente", "Seguro", "Global"].map((label) => (
                  <div key={label} className="rounded-lg border border-orvex-fog py-3 text-xs font-medium text-orvex-slate">
                    {label}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-center md:justify-end">
              <Calculator />
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="border-t border-orvex-fog bg-orvex-charcoal py-20 text-orvex-white">
          <div className="mx-auto max-w-6xl px-5">
            <h2 className="mb-12 text-2xl font-semibold tracking-tight md:text-3xl">Cómo funciona ORVEX</h2>
            <div className="grid gap-8 md:grid-cols-3">
              {[
                { step: "01", title: "Cotiza", desc: "Indica cuánto quieres enviar y a dónde. ORVEX te muestra una cotización clara al instante." },
                { step: "02", title: "Agrega al destinatario", desc: "Registra los datos de quien recibirá el dinero, de forma segura." },
                { step: "03", title: "Confirma", desc: "Revisa el detalle y confirma. ORVEX ruta la operación a través de infraestructura financiera autorizada." },
              ].map((item) => (
                <div key={item.step} className="rounded-xl2 border border-white/10 p-6">
                  <div className="mb-4 text-sm font-medium text-orvex-gold">{item.step}</div>
                  <h3 className="mb-2 text-lg font-semibold">{item.title}</h3>
                  <p className="text-sm leading-relaxed text-white/60">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* TRUST / DISCLOSURE */}
        <section className="mx-auto max-w-6xl px-5 py-20">
          <div className="rounded-xl2 border border-orvex-fog bg-orvex-fog/30 p-8 md:p-10">
            <h2 className="mb-3 text-xl font-semibold text-orvex-black">Transparencia ante todo</h2>
            <p className="max-w-2xl text-sm leading-relaxed text-orvex-slate">
              ORVEX es una plataforma tecnológica que conecta a las personas con proveedores de servicios
              financieros autorizados. ORVEX no es un banco, no custodia los fondos de sus usuarios y no
              ejecuta directamente transferencias financieras. Las cifras mostradas en este MVP son
              demostrativas.
            </p>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
