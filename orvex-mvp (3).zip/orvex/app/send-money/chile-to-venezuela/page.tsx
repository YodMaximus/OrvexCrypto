import type { Metadata } from "next";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Calculator from "@/components/Calculator";

export const metadata: Metadata = {
  title: "Enviar dinero de Chile a Venezuela — ORVEX",
  description: "Envía dinero de Chile a Venezuela de forma simple y transparente con ORVEX. Cotización clara, sin sorpresas.",
};

export default function ChileToVenezuelaPage() {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-6xl px-5 py-16">
        <div className="grid gap-12 md:grid-cols-2 md:items-start">
          <div>
            <h1 className="text-4xl font-semibold tracking-tight text-orvex-black">
              Enviar dinero de Chile 🇨🇱 a Venezuela 🇻🇪
            </h1>
            <p className="mt-5 max-w-md text-lg leading-relaxed text-orvex-slate">
              ORVEX conecta a personas en Chile con sus familiares en Venezuela a través de una
              cotización clara y un seguimiento transparente de cada envío.
            </p>
            <ul className="mt-8 space-y-3 text-sm text-orvex-slate">
              <li>· Cotización instantánea antes de confirmar</li>
              <li>· Seguimiento del estado en tiempo real</li>
              <li>· Sin cuentas ocultas ni letra chica</li>
            </ul>
          </div>
          <div className="flex justify-center md:justify-end">
            <Calculator />
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
