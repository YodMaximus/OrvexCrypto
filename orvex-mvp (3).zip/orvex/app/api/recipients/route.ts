import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { track } from "@/lib/analytics";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  return NextResponse.json({ recipients: db.listRecipients(user.id) });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "No autenticado." }, { status: 401 });

  const { name, country, payoutMethod, payoutDetails } = await req.json();
  if (!name || !country || !payoutMethod) {
    return NextResponse.json({ error: "Faltan campos requeridos." }, { status: 400 });
  }

  const recipient = db.createRecipient({
    userId: user.id,
    name,
    country,
    payoutMethod,
    payoutDetails: payoutDetails ?? {},
  });
  db.audit(user.id, "RECIPIENT_CREATED", { recipientId: recipient.id });
  track("recipient_added", { userId: user.id, recipientId: recipient.id });

  return NextResponse.json({ recipient });
}
