import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { isAdminEmail } from "@/lib/admin";

export async function GET() {
  const user = await getCurrentUser();
  if (!user || !isAdminEmail(user.email)) {
    return NextResponse.json({ error: "No autorizado." }, { status: 403 });
  }
  return NextResponse.json({
    stats: db.stats(),
    users: db.listUsers().map((u) => ({
      id: u.id,
      name: `${u.firstName} ${u.lastName}`,
      email: u.email,
      country: u.country,
      createdAt: u.createdAt,
      referralCode: u.referralCode,
    })),
    transfers: db.listAllTransactions(),
    referralHits: db.listReferralHits(),
  });
}
