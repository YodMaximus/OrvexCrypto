import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { db } from "@/lib/db";
import { routeQuote } from "@/lib/providers/routingEngine";
import { getCurrentUser } from "@/lib/auth";
import { track } from "@/lib/analytics";

export async function POST(req: NextRequest) {
  const { originCountry, destinationCountry, sendCurrency, receiveCurrency, sendAmount } = await req.json();

  if (!originCountry || !destinationCountry || !sendCurrency || !receiveCurrency || !sendAmount) {
    return NextResponse.json({ error: "Faltan campos para cotizar." }, { status: 400 });
  }
  if (Number(sendAmount) <= 0) {
    return NextResponse.json({ error: "El monto debe ser mayor a 0." }, { status: 400 });
  }

  const { recommended } = await routeQuote({
    originCountry,
    destinationCountry,
    sendCurrency,
    receiveCurrency,
    sendAmount: Number(sendAmount),
  });

  const user = await getCurrentUser();
  const orvexFee = Math.round(Number(sendAmount) * 0.005 * 100) / 100; // 0.5% demo fee de ORVEX

  const quote = db.saveQuote({
    id: randomUUID(),
    userId: user?.id ?? "anonymous",
    originCountry,
    destinationCountry,
    sendCurrency,
    receiveCurrency,
    sendAmount: Number(sendAmount),
    receiveAmount: recommended.receiveAmount,
    exchangeRate: recommended.exchangeRate,
    orvexFee,
    providerFee: recommended.providerFee,
    providerId: recommended.providerId,
    estimatedMinutes: recommended.estimatedMinutes,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 1000 * 60 * 10).toISOString(),
    isDemo: true,
  });

  track("quote_created", { userId: user?.id, quoteId: quote.id });

  return NextResponse.json({ quote, isDemo: true });
}
