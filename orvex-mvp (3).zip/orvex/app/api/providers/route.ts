import { NextRequest, NextResponse } from "next/server";
import { routeQuote } from "@/lib/providers/routingEngine";

export async function POST(req: NextRequest) {
  const { originCountry, destinationCountry, sendCurrency, receiveCurrency, sendAmount } = await req.json();
  const { recommended, options } = await routeQuote({
    originCountry,
    destinationCountry,
    sendCurrency,
    receiveCurrency,
    sendAmount: Number(sendAmount) || 100000,
  });
  return NextResponse.json({ recommended, options, isDemo: true });
}
