import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { track } from "@/lib/analytics";

export async function POST(req: NextRequest) {
  const { referralCode, source, campaign, medium } = await req.json();
  if (!referralCode) return NextResponse.json({ error: "referralCode requerido." }, { status: 400 });

  const hit = db.recordReferralHit({ referralCode, source, campaign, medium });
  track("referral_click", { referralCode, source, campaign, medium });

  return NextResponse.json({ hit });
}
