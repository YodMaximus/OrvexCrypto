import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, createSessionCookie } from "@/lib/auth";
import { track } from "@/lib/analytics";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { firstName, lastName, email, country, phone, password, acceptedTerms, acceptedPrivacy, referralCode } = body ?? {};

  if (!firstName || !lastName || !email || !country || !phone || !password) {
    return NextResponse.json({ error: "Faltan campos requeridos." }, { status: 400 });
  }
  if (!acceptedTerms || !acceptedPrivacy) {
    return NextResponse.json({ error: "Debes aceptar los Términos y la Política de Privacidad." }, { status: 400 });
  }
  if (String(password).length < 8) {
    return NextResponse.json({ error: "La contraseña debe tener al menos 8 caracteres." }, { status: 400 });
  }
  if (db.getUserByEmail(email)) {
    return NextResponse.json({ error: "Ya existe una cuenta con ese email." }, { status: 409 });
  }

  const { hash, salt } = hashPassword(password);
  const user = db.createUser({
    firstName,
    lastName,
    email,
    passwordHash: hash,
    passwordSalt: salt,
    country,
    phone,
    referredBy: referralCode ?? null,
  });

  await createSessionCookie(user.id);
  db.audit(user.id, "USER_SIGNUP", { email });
  db.notifyMock(user.id, "EMAIL", "Account created");
  track("signup_completed", { userId: user.id });

  return NextResponse.json({
    user: { id: user.id, firstName: user.firstName, email: user.email, referralCode: user.referralCode },
  });
}
