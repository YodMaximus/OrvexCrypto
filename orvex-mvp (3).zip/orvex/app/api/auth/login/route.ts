import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, createSessionCookie } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const { email, password } = await req.json();
  if (!email || !password) {
    return NextResponse.json({ error: "Email y contraseña son requeridos." }, { status: 400 });
  }
  const user = db.getUserByEmail(email);
  if (!user || !verifyPassword(password, user.passwordHash, user.passwordSalt)) {
    return NextResponse.json({ error: "Credenciales inválidas." }, { status: 401 });
  }
  await createSessionCookie(user.id);
  db.audit(user.id, "USER_LOGIN", {});
  return NextResponse.json({ user: { id: user.id, firstName: user.firstName, email: user.email } });
}
