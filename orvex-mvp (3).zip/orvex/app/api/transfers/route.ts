import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { track } from "@/lib/analytics";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  return NextResponse.json({ transfers: db.listTransactionsByUser(user.id) });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "No autenticado." }, { status: 401 });

  const { quoteId, recipientId } = await req.json();
  const quote = db.getQuote(quoteId);
  const recipient = db.getRecipient(recipientId);

  if (!quote) return NextResponse.json({ error: "Cotización no encontrada o expirada." }, { status: 404 });
  if (!recipient || recipient.userId !== user.id) {
    return NextResponse.json({ error: "Destinatario inválido." }, { status: 400 });
  }
  if (new Date(quote.expiresAt).getTime() < Date.now()) {
    return NextResponse.json({ error: "La cotización expiró, genera una nueva." }, { status: 410 });
  }

  const transaction = db.createTransaction({
    userId: user.id,
    recipientId: recipient.id,
    originCountry: quote.originCountry,
    destinationCountry: quote.destinationCountry,
    sendAmount: quote.sendAmount,
    sendCurrency: quote.sendCurrency,
    receiveAmount: quote.receiveAmount,
    receiveCurrency: quote.receiveCurrency,
    orvexFee: quote.orvexFee,
    providerFee: quote.providerFee,
    providerId: quote.providerId,
    status: "PENDING",
  });

  db.audit(user.id, "TRANSFER_CREATED", { transactionId: transaction.id });
  db.notifyMock(user.id, "EMAIL", "Transfer created");
  track("transfer_confirmed", { userId: user.id, transactionId: transaction.id });

  // Simulación de progreso asíncrono (DEMO). En producción, esto lo
  // dispara un webhook real del PaymentProviderAdapter.
  setTimeout(() => {
    db.updateTransactionStatus(transaction.id, "PROCESSING", "Provider processing (DEMO)");
  }, 4000);
  setTimeout(() => {
    db.updateTransactionStatus(transaction.id, "COMPLETED", "Transfer completed (DEMO)");
    db.notifyMock(user.id, "EMAIL", "Transfer completed");
    track("transfer_completed", { userId: user.id, transactionId: transaction.id });
  }, 10000);

  return NextResponse.json({ transaction, isDemo: true });
}
