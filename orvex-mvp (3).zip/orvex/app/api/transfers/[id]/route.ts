import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "No autenticado." }, { status: 401 });

  const transaction = db.getTransaction(params.id);
  if (!transaction || transaction.userId !== user.id) {
    return NextResponse.json({ error: "Transferencia no encontrada." }, { status: 404 });
  }
  const events = db.getTransactionEvents(params.id);
  const recipient = db.getRecipient(transaction.recipientId);

  return NextResponse.json({ transaction, events, recipient });
}
