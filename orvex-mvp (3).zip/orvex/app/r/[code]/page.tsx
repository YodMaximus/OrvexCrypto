import { redirect } from "next/navigation";
import { db } from "@/lib/db";

export default async function ReferralRedirect({
  params,
  searchParams,
}: {
  params: { code: string };
  searchParams: { source?: string; campaign?: string; medium?: string };
}) {
  db.recordReferralHit({
    referralCode: params.code,
    source: searchParams.source,
    campaign: searchParams.campaign,
    medium: searchParams.medium,
  });
  redirect(`/signup?ref=${encodeURIComponent(params.code)}`);
}
