"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";

interface Event {
  id: string;
  status: string;
  note: string;
  createdAt: string;
}
interface Transaction {
  id: string;
  sendAmount: number;
  sendCurrency: string;
  receiveAmount: number;
  receiveCurrency: string;
  status: string;
  providerId: string;
}

const STAGES = ["PENDING", "PROCESSING", "COMPLETED"];

export default function TransferTrackingPage() {
  const { id } = useParams<{ id: string }>();
  const [transaction, setTransaction] = useState<Transaction | null>(null);
  const [events, setEvents] = useState<Event[]>([]);
  const [recipientName, setRecipientName] = useState("");

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    async function load() {
      const res = await fetch(`/api/transfers/${id}`);
      const data = await res.json();
      if (res.ok) {
        setTransaction(data.transaction);
        setEvents(data.events);
        setRecipientName(data.recipient?.name ?? "");
        if (["COMPLETED", "FAILED", "CANCELLED"].includes(data.transaction.status)) {
          clearInterval(interval);
        }
      }
    }
    load();
    interval = setInterval(load, 3000);
    return () => clearInterval(interval);
  }, [id]);

  if (!transaction) {
    return (
      <>
        <Navbar />
        <main className="mx-auto max-w-lg px-5 py-12 text-sm text-orvex-mist">Cargando…</main>
      </>
    );
  }

  const stageIndex = STAGES.indexOf(transaction.status);

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-lg px-5 py-12">
        <p className="mb-1 text-xs uppercase tracking-wide text-orvex-mist">ORVEX Transaction ID</p>
        <p className="mb-8 text-sm font-mono text-orvex-black">{transaction.id}</p>

        <h1 className="mb-6 text-2xl font-semibold text-orvex-black">
          ${transaction.sendAmount.toLocaleString("es-CL")} {transaction.sendCurrency} → {recipientName}
        </h1>

        <div className="mb-8 flex items-center gap-2">
          {STAGES.map((s, i) => (
            <div key={s} className={`h-1.5 flex-1 rounded-full ${i <= stageIndex ? "bg-orvex-black" : "bg-orvex-fog"}`} />
          ))}
        </div>

        <div className="mb-8 rounded-xl2 border border-orvex-fog p-5 text-sm">
          <div className="flex justify-between"><span className="text-orvex-mist">Estado</span><span className="font-semibold text-orvex-black">{transaction.status}</span></div>
          <div className="mt-2 flex justify-between"><span className="text-orvex-mist">Destinatario recibe</span><span className="text-orvex-black">${transaction.receiveAmount.toLocaleString("es-CL")} {transaction.receiveCurrency}</span></div>
          <div className="mt-2 flex justify-between"><span className="text-orvex-mist">Proveedor</span><span className="text-orvex-black">{transaction.providerId} (demo)</span></div>
        </div>

        <h2 className="mb-3 text-sm font-semibold text-orvex-black">Historial</h2>
        <div className="space-y-3">
          {events.map((e) => (
            <div key={e.id} className="flex gap-3 text-sm">
              <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-orvex-gold" />
              <div>
                <p className="text-orvex-black">{e.note}</p>
                <p className="text-xs text-orvex-mist">{new Date(e.createdAt).toLocaleString("es-CL")}</p>
              </div>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
