"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";

interface Recipient {
  id: string;
  name: string;
  country: string;
  payoutMethod: string;
}
interface Quote {
  id: string;
  sendAmount: number;
  receiveAmount: number;
  orvexFee: number;
  providerFee: number;
  exchangeRate: number;
  estimatedMinutes: number;
  providerId: string;
}

const STEPS = ["Monto", "Destinatario", "Revisar", "Confirmado"] as const;

export default function TransferWizard() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [amount, setAmount] = useState(300000);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [recipientId, setRecipientId] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [transferId, setTransferId] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/recipients").then((r) => r.json()).then((d) => setRecipients(d.recipients ?? []));
  }, []);

  async function getQuote() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/quotes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ originCountry: "CL", destinationCountry: "VE", sendCurrency: "CLP", receiveCurrency: "USD", sendAmount: amount }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setQuote(data.quote);
      setStep(1);
    } catch (e) {
      setError("No se pudo generar la cotización.");
    } finally {
      setLoading(false);
    }
  }

  async function confirmTransfer() {
    if (!quote || !recipientId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/transfers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quoteId: quote.id, recipientId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setTransferId(data.transaction.id);
      setStep(3);
    } catch (e) {
      setError((e as Error).message || "No se pudo confirmar la transferencia.");
    } finally {
      setLoading(false);
    }
  }

  const selectedRecipient = recipients.find((r) => r.id === recipientId);

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-lg px-5 py-12">
        <div className="mb-8 flex items-center gap-2">
          {STEPS.map((s, i) => (
            <div key={s} className="flex flex-1 items-center gap-2">
              <div className={`h-1.5 flex-1 rounded-full ${i <= step ? "bg-orvex-black" : "bg-orvex-fog"}`} />
            </div>
          ))}
        </div>

        {step === 0 && (
          <div>
            <h1 className="mb-1 text-2xl font-semibold text-orvex-black">¿Cuánto quieres enviar?</h1>
            <p className="mb-6 text-sm text-orvex-mist">Chile 🇨🇱 → Venezuela 🇻🇪</p>
            <div className="mb-4 flex items-center rounded-lg border border-orvex-fog px-4 py-3">
              <input type="number" min={1000} value={amount} onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full bg-transparent text-2xl font-semibold outline-none" />
              <span className="text-sm text-orvex-mist">CLP</span>
            </div>
            {error && <p className="mb-4 text-sm text-red-600">{error}</p>}
            <button onClick={getQuote} disabled={loading}
              className="w-full rounded-full bg-orvex-black py-3.5 text-sm font-semibold text-orvex-white hover:bg-orvex-graphite disabled:opacity-50">
              {loading ? "Cotizando…" : "Continuar"}
            </button>
          </div>
        )}

        {step === 1 && quote && (
          <div>
            <h1 className="mb-1 text-2xl font-semibold text-orvex-black">Elige un destinatario</h1>
            <p className="mb-6 text-sm text-orvex-mist">
              El destinatario recibe ${quote.receiveAmount.toLocaleString("es-CL")} USD (demo)
            </p>
            {recipients.length === 0 ? (
              <p className="mb-4 text-sm text-orvex-mist">
                No tienes destinatarios aún. Ve a "Mis destinatarios" en el dashboard para agregar uno antes de continuar.
              </p>
            ) : (
              <div className="mb-6 space-y-2">
                {recipients.map((r) => (
                  <label key={r.id}
                    className={`flex cursor-pointer items-center justify-between rounded-xl2 border p-4 ${recipientId === r.id ? "border-orvex-black" : "border-orvex-fog"}`}>
                    <div>
                      <p className="text-sm font-medium text-orvex-black">{r.name}</p>
                      <p className="text-xs text-orvex-mist">{r.country} · {r.payoutMethod}</p>
                    </div>
                    <input type="radio" name="recipient" checked={recipientId === r.id} onChange={() => setRecipientId(r.id)} />
                  </label>
                ))}
              </div>
            )}
            <button onClick={() => setStep(2)} disabled={!recipientId}
              className="w-full rounded-full bg-orvex-black py-3.5 text-sm font-semibold text-orvex-white hover:bg-orvex-graphite disabled:opacity-40">
              Continuar
            </button>
          </div>
        )}

        {step === 2 && quote && selectedRecipient && (
          <div>
            <h1 className="mb-6 text-2xl font-semibold text-orvex-black">Revisar transferencia</h1>
            <div className="mb-6 space-y-3 rounded-xl2 border border-orvex-fog p-5 text-sm">
              <Row label="Tú envías" value={`$${quote.sendAmount.toLocaleString("es-CL")} CLP`} />
              <Row label="Destinatario" value={selectedRecipient.name} />
              <Row label="País" value="Venezuela 🇻🇪" />
              <Row label="El destinatario recibe" value={`$${quote.receiveAmount.toLocaleString("es-CL")} USD`} bold />
              <Row label="Comisión ORVEX" value={`$${quote.orvexFee.toLocaleString("es-CL")} CLP`} />
              <Row label="Comisión del proveedor" value={`$${quote.providerFee.toLocaleString("es-CL")} CLP`} />
              <Row label="Tiempo estimado" value={`${quote.estimatedMinutes} min`} />
            </div>
            {error && <p className="mb-4 text-sm text-red-600">{error}</p>}
            <button onClick={confirmTransfer} disabled={loading}
              className="w-full rounded-full bg-orvex-black py-3.5 text-sm font-semibold text-orvex-white hover:bg-orvex-graphite disabled:opacity-50">
              {loading ? "Confirmando…" : "Confirmar transferencia"}
            </button>
          </div>
        )}

        {step === 3 && transferId && (
          <div className="text-center">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-green-100 text-green-700">✓</div>
            <h1 className="mb-2 text-2xl font-semibold text-orvex-black">Transferencia iniciada</h1>
            <p className="mb-8 text-sm text-orvex-mist">Puedes seguir el estado en tiempo real.</p>
            <button onClick={() => router.push(`/dashboard/transfers/${transferId}`)}
              className="w-full rounded-full bg-orvex-black py-3.5 text-sm font-semibold text-orvex-white hover:bg-orvex-graphite">
              Ver estado de la transferencia
            </button>
          </div>
        )}
      </main>
    </>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex justify-between">
      <span className="text-orvex-mist">{label}</span>
      <span className={bold ? "font-semibold text-orvex-black" : "text-orvex-black"}>{value}</span>
    </div>
  );
}
