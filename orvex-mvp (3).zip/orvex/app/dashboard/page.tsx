"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";

interface Transfer {
  id: string;
  destinationCountry: string;
  sendAmount: number;
  sendCurrency: string;
  receiveAmount: number;
  receiveCurrency: string;
  status: string;
  createdAt: string;
}

const statusLabel: Record<string, string> = {
  PENDING: "Pendiente",
  PROCESSING: "Procesando",
  COMPLETED: "Completada",
  FAILED: "Fallida",
  CANCELLED: "Cancelada",
};

const statusColor: Record<string, string> = {
  PENDING: "bg-orvex-fog text-orvex-slate",
  PROCESSING: "bg-orvex-gold/20 text-orvex-gold",
  COMPLETED: "bg-green-100 text-green-700",
  FAILED: "bg-red-100 text-red-700",
  CANCELLED: "bg-orvex-fog text-orvex-slate",
};

export default function DashboardPage() {
  const [user, setUser] = useState<{ firstName: string; referralCode: string } | null>(null);
  const [transfers, setTransfers] = useState<Transfer[]>([]);

  useEffect(() => {
    fetch("/api/auth/me").then((r) => r.json()).then((d) => setUser(d.user));
    fetch("/api/transfers").then((r) => r.json()).then((d) => setTransfers(d.transfers ?? []));
  }, []);

  const referralLink = user ? `${window.location.origin}/r/${user.referralCode}` : "";

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-4xl px-5 py-12">
        <h1 className="text-2xl font-semibold text-orvex-black">
          Hola, {user?.firstName ?? "…"}
        </h1>

        <div className="mt-6 rounded-xl2 border border-orvex-fog bg-orvex-charcoal p-6 text-orvex-white">
          <p className="text-xs uppercase tracking-wide text-white/50">Balance</p>
          <p className="mt-1 text-lg font-medium">ORVEX no custodia fondos</p>
          <p className="mt-1 text-xs text-white/50">
            ORVEX es una plataforma tecnológica. Los fondos son gestionados por proveedores financieros autorizados.
          </p>
        </div>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Link href="/dashboard/transfer"
            className="rounded-full bg-orvex-black px-6 py-3 text-center text-sm font-semibold text-orvex-white hover:bg-orvex-graphite">
            Enviar dinero
          </Link>
          <Link href="/dashboard/recipients"
            className="rounded-full border border-orvex-fog px-6 py-3 text-center text-sm font-semibold text-orvex-black hover:border-orvex-black">
            Mis destinatarios
          </Link>
        </div>

        {user && (
          <div className="mt-8 rounded-xl2 border border-orvex-fog p-5">
            <p className="text-sm font-medium text-orvex-black">Tu link de referidos</p>
            <p className="mt-1 text-xs text-orvex-mist">Compártelo en tus redes — ORVEX registra de dónde viene cada usuario.</p>
            <div className="mt-3 flex items-center gap-2 rounded-lg bg-orvex-fog/40 px-3 py-2 text-sm text-orvex-black">
              <code className="flex-1 truncate">{referralLink}</code>
              <button
                onClick={() => navigator.clipboard.writeText(referralLink)}
                className="rounded-full bg-orvex-black px-3 py-1 text-xs font-medium text-white"
              >
                Copiar
              </button>
            </div>
          </div>
        )}

        <h2 className="mt-10 mb-4 text-lg font-semibold text-orvex-black">Transferencias recientes</h2>
        {transfers.length === 0 ? (
          <p className="text-sm text-orvex-mist">Aún no tienes transferencias.</p>
        ) : (
          <div className="space-y-3">
            {transfers.map((t) => (
              <Link key={t.id} href={`/dashboard/transfers/${t.id}`}
                className="flex items-center justify-between rounded-xl2 border border-orvex-fog p-4 hover:border-orvex-black">
                <div>
                  <p className="text-sm font-medium text-orvex-black">
                    ${t.sendAmount.toLocaleString("es-CL")} {t.sendCurrency} → ${t.receiveAmount.toLocaleString("es-CL")} {t.receiveCurrency}
                  </p>
                  <p className="text-xs text-orvex-mist">{new Date(t.createdAt).toLocaleString("es-CL")}</p>
                </div>
                <span className={`rounded-full px-3 py-1 text-xs font-medium ${statusColor[t.status]}`}>
                  {statusLabel[t.status]}
                </span>
              </Link>
            ))}
          </div>
        )}
      </main>
    </>
  );
}
