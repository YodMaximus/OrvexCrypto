"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";

interface Recipient {
  id: string;
  name: string;
  country: string;
  payoutMethod: string;
}

export default function RecipientsPage() {
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [form, setForm] = useState({ name: "", country: "Venezuela", payoutMethod: "Transferencia bancaria", bankAccount: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function load() {
    fetch("/api/recipients").then((r) => r.json()).then((d) => setRecipients(d.recipients ?? []));
  }
  useEffect(load, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/recipients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          country: form.country,
          payoutMethod: form.payoutMethod,
          payoutDetails: { bankAccount: form.bankAccount },
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "No se pudo agregar el destinatario.");
      setForm({ name: "", country: "Venezuela", payoutMethod: "Transferencia bancaria", bankAccount: "" });
      load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-2xl px-5 py-12">
        <h1 className="mb-8 text-2xl font-semibold text-orvex-black">Mis destinatarios</h1>

        <div className="mb-10 space-y-3">
          {recipients.length === 0 && <p className="text-sm text-orvex-mist">Aún no tienes destinatarios.</p>}
          {recipients.map((r) => (
            <div key={r.id} className="rounded-xl2 border border-orvex-fog p-4">
              <p className="text-sm font-medium text-orvex-black">{r.name}</p>
              <p className="text-xs text-orvex-mist">{r.country} · {r.payoutMethod}</p>
            </div>
          ))}
        </div>

        <h2 className="mb-4 text-lg font-semibold text-orvex-black">+ Agregar destinatario</h2>
        <form onSubmit={handleSubmit} className="space-y-3">
          <input required placeholder="Nombre completo" value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full rounded-lg border border-orvex-fog px-4 py-3 text-sm outline-none focus:border-orvex-black" />
          <input required placeholder="País" value={form.country}
            onChange={(e) => setForm({ ...form, country: e.target.value })}
            className="w-full rounded-lg border border-orvex-fog px-4 py-3 text-sm outline-none focus:border-orvex-black" />
          <select value={form.payoutMethod} onChange={(e) => setForm({ ...form, payoutMethod: e.target.value })}
            className="w-full rounded-lg border border-orvex-fog px-4 py-3 text-sm outline-none focus:border-orvex-black">
            <option>Transferencia bancaria</option>
            <option>Efectivo (retiro en punto físico)</option>
            <option>Billetera digital</option>
          </select>
          <input required placeholder="Número de cuenta / referencia de pago" value={form.bankAccount}
            onChange={(e) => setForm({ ...form, bankAccount: e.target.value })}
            className="w-full rounded-lg border border-orvex-fog px-4 py-3 text-sm outline-none focus:border-orvex-black" />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button disabled={loading} type="submit"
            className="w-full rounded-full bg-orvex-black py-3.5 text-sm font-semibold text-orvex-white hover:bg-orvex-graphite disabled:opacity-50">
            {loading ? "Guardando…" : "Agregar destinatario"}
          </button>
        </form>
      </main>
    </>
  );
}
